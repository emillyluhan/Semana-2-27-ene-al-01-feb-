package com.example.proyectokotlinfundamentos

// Función principal
fun main() {
    problema14()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema14() {
    println("Dame num1:")
    val num1 = readLine()!!.toInt()

    println("Dame num2:")
    val num2 = readLine()!!.toInt()

    println("Dame num3:")
    val num3 = readLine()!!.toInt()

    val mayor = maxOf(num1, num2, num3)  // Determinamos el número mayor

    // Verificamos cuántas veces aparece el número mayor
    val esEmpate = listOf(num1, num2, num3).count { it == mayor } > 1

    // Mostramos el resultado
    println(if (esEmpate) "Hay un empate!" else mayor)
}
