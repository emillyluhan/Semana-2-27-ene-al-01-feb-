package com.example.proyectokotlinfundamentos

// Función principal
fun main() {
    problema5()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema5() {
    println("Estudiantes (e):")
    val estudiantes = readLine()!!.toInt()

    println("Manzanas (m):")
    val manzanas = readLine()!!.toInt()

    val manzanasPorEstudiante = manzanas / estudiantes
    val manzanasRestantes = manzanas % estudiantes

    println("Cada estudiante recibirá: $manzanasPorEstudiante manzanas.")
    println("Quedarán en la canasta: $manzanasRestantes manzanas.")
}
