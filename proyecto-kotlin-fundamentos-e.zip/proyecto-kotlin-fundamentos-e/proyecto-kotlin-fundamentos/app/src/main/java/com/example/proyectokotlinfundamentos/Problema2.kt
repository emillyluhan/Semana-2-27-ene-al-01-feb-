package com.example.proyectokotlinfundamentos

// Función principal
fun main() {
    problema2()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema2() {
    println("Ingresa a:")
    val a = readLine()!!.toInt()

    println("Ingresa b:")
    val b = readLine()!!.toInt()

    println("$a + $b = ${a + b}")
}
