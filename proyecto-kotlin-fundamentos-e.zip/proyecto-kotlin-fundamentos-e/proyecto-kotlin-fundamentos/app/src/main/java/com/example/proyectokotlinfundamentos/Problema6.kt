package com.example.proyectokotlinfundamentos

// Función principal
fun main() {
    problema6()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema6() {
    println("Dame un número entero:")
    val numero = readLine()!!.toInt()

    // Extraemos y sumamos los dígitos del número
    val suma = (numero / 100) + (numero / 10 % 10) + (numero % 10)

    println("La suma de los dígitos del número $numero es igual a $suma.")
}
