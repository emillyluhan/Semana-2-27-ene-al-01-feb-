package com.example.proyectokotlinfundamentos

// Función principal
fun main() {
    problema7()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema7() {
    println("¿Cuántos sonidos del grillo escuchaste por minuto?")
    val sonidos = readLine()!!.toInt()

    if (sonidos < 0) {
        println("¿Estás seguro de que un grillo puede hacer ese número de sonidos?")
    } else {
        val temperatura = sonidos / 4.0 + 40
        println("Dados los sonidos del grillo, la temperatura es de $temperatura °F.")
    }
}

