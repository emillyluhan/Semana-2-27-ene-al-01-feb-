package com.example.proyectokotlinfundamentos

// Función principal
fun main() {
    problema11()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema11() {
    println("Dame el presupuesto:")
    val presupuesto = readLine()!!.toInt()

    val comida = pedirValor("comida")  // Leer valor de la comida
    val electricidad = pedirValor("electricidad")  // Leer valor de la electricidad
    val internet = pedirValor("internet")  // Leer valor del internet
    val arriendo = pedirValor("arriendo")  // Leer valor del arriendo

    val totalGastos = comida + electricidad + internet + arriendo  // Calcular total de gastos

    // Determinar mensaje según comparación de presupuesto y gastos
    val mensaje = if (presupuesto < totalGastos) "Rayos estoy quebrado(a)!" else "Vamos melos!"
    println(mensaje)
}

// Función para leer el valor de un ítem
fun pedirValor(item: String): Int {
    println("Dame el valor de la $item:")
    return readLine()!!.toInt()
}
