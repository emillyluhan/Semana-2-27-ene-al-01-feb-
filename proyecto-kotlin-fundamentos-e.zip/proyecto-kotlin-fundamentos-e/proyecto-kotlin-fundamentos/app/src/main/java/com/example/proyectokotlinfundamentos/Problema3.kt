package com.example.proyectokotlinfundamentos

// Función principal
fun main() {
    problema3()
}

// Función que debe desarrollar la lógica para la solución del problema

fun problema3() {
    // Solicita la asignatura al usuario
    println("Ingresa la asignatura:")
    val asignatura = readLine()!!

    // Lee las notas de los tres cortes académicos usando la función readNota
    val nota1 = readNota("primer")
    val nota2 = readNota("segundo")
    val nota3 = readNota("tercer")

    // Calcula la calificación final teniendo en cuenta los pesos de los cortes
    val calificacionFinal = (nota1 * 0.33) + (nota2 * 0.33) + (nota3 * 0.34)

    // Muestra la asignatura y la calificación final en pantalla
    println("Asignatura: $asignatura")
    println("Definitiva: ${"%.3f".format(calificacionFinal)}")
}

// Función que solicita y lee la nota de un corte académico específico
fun readNota(corte: String): Double {
    println("Ingresa nota $corte corte:")  // Solicita la nota del corte específico
    return readLine()!!.toDouble()  // Lee la nota ingresada y la convierte a Double
}


