package com.example.proyectokotlinfundamentos

// Función principal
fun main() {
    problema8()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema8() {
    println("Dame la base:")
    val base = readLine()!!.toInt()

    println("Dame el exponente:")
    val exponente = readLine()!!.toInt()

    // Calculamos la base elevada al exponente
    val resultado = Math.pow(base.toDouble(), exponente.toDouble())

    // Validamos si el resultado es mayor a 5000
    val mensaje = if (resultado > 5000) "Muy grande." else "Números óptimos."
    println(mensaje)
}

