package com.example.proyectokotlinfundamentos

// Función principal
fun main() {
    problema13()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema13() {
    println("Dame un numero:")
    val num = readLine()!!.toInt()

    val centena = num / 100
    val decena = (num / 10) % 10
    val unidad = num % 10

    println(if (centena < decena && decena < unidad) "SÍ" else "NO")
}
