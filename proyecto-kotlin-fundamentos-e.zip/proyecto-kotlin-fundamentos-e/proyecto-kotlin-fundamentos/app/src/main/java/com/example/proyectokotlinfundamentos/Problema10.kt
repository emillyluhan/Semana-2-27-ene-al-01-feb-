package com.example.proyectokotlinfundamentos

// Función principal
fun main() {
    problema10()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema10() {
    println("Dame num:")
    val num = readLine()!!.toInt()

    val mensaje = if (num % 10 == 0) "Divisible." else "No divisible."
    println(mensaje)
}
