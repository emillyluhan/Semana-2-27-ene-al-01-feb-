package com.example.proyectokotlinfundamentos

// Función principal
fun main() {
    problema9()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema9() {
    println("Dame num1:")
    val num1 = readLine()!!.toInt()

    println("Dame num2:")
    val num2 = readLine()!!.toInt()

    val mensaje = if (num1 > 2 * num2) "Wow!" else "Aburrido!"
    println(mensaje)
}

