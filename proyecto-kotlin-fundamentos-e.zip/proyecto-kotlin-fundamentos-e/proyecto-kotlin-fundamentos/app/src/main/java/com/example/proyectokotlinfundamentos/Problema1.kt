package com.example.proyectokotlinfundamentos

// Descripción:Taller Semana 2 (27 ene al 01 feb) - Kotlin Fundamentos
// Nombre: Emilly Luhan Martinez Osorio
// Fecha: 06/02/2025

// Función principal
fun main() {
    problema1()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema1() {
    // Desarrolle aquí la lógica
    print("Hola Mundo Kotlin!")
}