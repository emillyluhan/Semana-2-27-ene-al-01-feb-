package com.example.proyectokotlinfundamentos

// Función principal
fun main() {
    problema15()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema15() {
    println("Dame un numero de 4 cifras:")
    val num = readLine()!!.toInt()

    // Verificar si el número es un palíndromo
    val esPalindromo = num.toString() == num.toString().reversed()

    println(if (esPalindromo) "SÍ" else "NO")
}

