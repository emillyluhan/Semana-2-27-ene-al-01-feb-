package com.example.proyectokotlinfundamentos

// Función principal
fun main() {
    problema16()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema16() {
    println("n:")
    val n = readLine()!!.toInt()

    println("m:")
    val m = readLine()!!.toInt()

    println("k:")
    val k = readLine()!!.toInt()

    // Verificar si se puede dividir la barra de chocolate en k cuadrados
    val esPosible = (k % n == 0 && k / n <= m) || (k % m == 0 && k / m <= n)
    println(if (esPosible) "SÍ" else "NO")
}
