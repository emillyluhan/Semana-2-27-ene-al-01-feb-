package com.example.proyectokotlinfundamentos


// Función principal
fun main() {
    problema4()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema4() {
    val impuesto = 0.18

    // Solicitar el precio de los tres artículos utilizando una función auxiliar
    val articulo1 = leerValorArticulo(1)
    val articulo2 = leerValorArticulo(2)
    val articulo3 = leerValorArticulo(3)

    // Calcular el valor total neto (sin impuestos)
    val totalNeto = articulo1 + articulo2 + articulo3

    // Calcular el total con impuesto
    val totalConImpuesto = totalNeto * (1 + impuesto)

    // Mostrar los resultados
    println("Valor neto: $totalNeto")
    println("Valor total: $totalConImpuesto")
}

// Función auxiliar para leer el valor de un artículo
fun leerValorArticulo(numero: Int): Double {
    println("Ingresa valor artículo $numero:")
    return readLine()!!.toDouble()
}
