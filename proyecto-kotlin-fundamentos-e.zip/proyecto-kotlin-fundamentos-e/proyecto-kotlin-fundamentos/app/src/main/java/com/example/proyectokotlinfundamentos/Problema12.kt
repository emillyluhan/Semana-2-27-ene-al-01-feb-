package com.example.proyectokotlinfundamentos

// Función principal
fun main() {
    problema12()  // Llamamos a la función que contiene la lógica del problema
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema12() {
    println("Dame num1:")
    val num1 = readLine()!!.toInt()  // Leemos el primer número como entero

    println("Dame num2:")
    val num2 = readLine()!!.toInt()  // Leemos el segundo número como entero

    println("Dame num3:")
    val num3 = readLine()!!.toInt()  // Leemos el tercer número como entero

    // Verificamos cuántos números son iguales
    val igual = if (num1 == num2 && num2 == num3) {
        3  // Los tres números son iguales
    } else if (num1 == num2 || num1 == num3 || num2 == num3) {
        2  // Dos de los tres números son iguales
    } else {
        0  // Ningún número es igual
    }

    println(igual)  // Imprimimos el resultado
}

