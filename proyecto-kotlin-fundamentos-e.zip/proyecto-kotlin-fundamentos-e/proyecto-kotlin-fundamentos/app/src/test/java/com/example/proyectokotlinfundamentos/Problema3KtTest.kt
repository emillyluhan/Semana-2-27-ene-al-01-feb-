// Función principal
fun main() {
    problema3()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema3() {
    // Solicita la asignatura al usuario
    println("Ingresa la asignatura:")
    val asignatura = readLine()!!

    // Solicita las notas de los tres cortes académicos al usuario
    println("Ingresa nota primer corte:")
    val nota1 = readLine()!!.toDouble()

    println("Ingresa nota segundo corte:")
    val nota2 = readLine()!!.toDouble()

    println("Ingresa nota tercer corte:")
    val nota3 = readLine()!!.toDouble()

    // Calcula la calificación final teniendo en cuenta los pesos de los cortes
    val calificacionFinal = (nota1 * 0.33) + (nota2 * 0.33) + (nota3 * 0.34)

    // Muestra la asignatura y la calificación final en pantalla
    println("Asignatura: $asignatura")
    println("Definitiva: ${"%.3f".format(calificacionFinal)}")
}
